
CREATE DATABASE sp_vms;
USE sp_vms;

CREATE TABLE users(
 id INT AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(50),
 password VARCHAR(255),
 role VARCHAR(20)
);

CREATE TABLE visitors(
 id INT AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(100),
 phone VARCHAR(20),
 email VARCHAR(100),
 gender VARCHAR(10),
 address TEXT,
 purpose VARCHAR(200),
 department VARCHAR(100),
 person_to_meet VARCHAR(100),
 photo_path VARCHAR(255),
 document_path VARCHAR(255),
 checkin_time DATETIME
);
