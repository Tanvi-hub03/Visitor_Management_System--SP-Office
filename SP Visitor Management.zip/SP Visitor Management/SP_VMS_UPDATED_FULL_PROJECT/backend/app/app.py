
from flask import Flask, render_template, request, redirect, session, jsonify
import pymysql, os
from werkzeug.security import check_password_hash
from datetime import datetime

app = Flask(__name__)
app.secret_key = "sp_sangli_secure"

UPLOAD_FOLDER = "static/uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def get_db():
    return pymysql.connect(
        host="localhost",
        user="root",
        password="root",
        database="sp_vms",
        cursorclass=pymysql.cursors.DictCursor
    )

@app.route("/", methods=["GET","POST"])
def login():
    if request.method == "POST":
        u = request.form["username"]
        p = request.form["password"]
        db = get_db()
        cur = db.cursor()
        cur.execute("SELECT * FROM users WHERE username=%s",(u,))
        user = cur.fetchone()
        if user and check_password_hash(user["password"], p):
            session["role"] = user["role"]
            return redirect("/operator" if user["role"]=="operator" else "/admin")
        return "Invalid Login"
    return render_template("login.html")

@app.route("/operator")
def operator():
    if session.get("role")!="operator":
        return redirect("/")
    return render_template("operator_form.html")

@app.route("/save-visitor", methods=["POST"])
def save_visitor():
    f = request.form
    photo = request.files.get("photo")
    doc = request.files.get("document")
    photo_p = doc_p = None

    if photo:
        photo_p = os.path.join(UPLOAD_FOLDER, photo.filename)
        photo.save(photo_p)
    if doc:
        doc_p = os.path.join(UPLOAD_FOLDER, doc.filename)
        doc.save(doc_p)

    db = get_db()
    cur = db.cursor()
    cur.execute(
        "INSERT INTO visitors (full_name, phone, email, gender, address, purpose, department, person_to_meet, photo_path, document_path, checkin_time) "
        "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
        (
            f["full_name"], f["phone"], f["email"], f["gender"], f["address"],
            f["purpose"], f["department"], f["person_to_meet"],
            photo_p, doc_p, datetime.now()
        )
    )
    db.commit()
    return redirect("/operator")

@app.route("/admin")
def admin():
    if session.get("role") not in ["admin","super_admin"]:
        return redirect("/")
    return render_template("admin_dashboard.html")

@app.route("/api/department-chart")
def dept_chart():
    db = get_db()
    cur = db.cursor()
    cur.execute("SELECT department, COUNT(*) total FROM visitors GROUP BY department")
    r = cur.fetchall()
    return jsonify({
        "labels":[i["department"] for i in r],
        "values":[i["total"] for i in r]
    })

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")
@app.route("/api/visitors")
def get_visitors():
    if session.get("role") not in ["admin", "super_admin", "operator"]:
        return redirect("/")

    start = request.args.get("start")
    end = request.args.get("end")
    dept = request.args.get("department")

    query = "SELECT * FROM visitors WHERE 1=1"
    params = []

    if start and end:
        query += " AND DATE(checkin_time) BETWEEN %s AND %s"
        params.extend([start, end])

    if dept and dept != "All":
        query += " AND department=%s"
        params.append(dept)

    db = get_db()
    cur = db.cursor()
    cur.execute(query, params)
    data = cur.fetchall()

    return jsonify(data)
@app.route("/update-visitor/<int:id>", methods=["POST"])
def update_visitor(id):
    if session.get("role") not in ["admin", "super_admin", "operator"]:
        return redirect("/")

    f = request.form
    db = get_db()
    cur = db.cursor()

    cur.execute("""
        UPDATE visitors SET
        full_name=%s,
        phone=%s,
        purpose=%s,
        department=%s,
        person_to_meet=%s
        WHERE id=%s
    """, (
        f["full_name"], f["phone"], f["purpose"],
        f["department"], f["person_to_meet"], id
    ))
    db.commit()
    return redirect("/visitor-list")
@app.route("/visitor-list")
def visitor_list():
    if session.get("role") not in ["admin", "super_admin", "operator"]:
        return redirect("/")
    return render_template("visitor_list.html")
@app.route("/edit/<int:id>")
def edit_visitor(id):
    if session.get("role") not in ["admin","super_admin","operator"]:
        return redirect("/")
    db=get_db()
    cur=db.cursor()
    cur.execute("SELECT * FROM visitors WHERE id=%s",(id,))
    v=cur.fetchone()
    return render_template("edit_visitor.html", v=v)

from datetime import date

@app.route("/api/hourly-chart")
def hourly_chart():
    if session.get("role") not in ["admin", "super_admin"]:
        return redirect("/")

    # Today hourly data
    db = get_db()
    cur = db.cursor()
    cur.execute("""
        SELECT HOUR(checkin_time) AS hr, COUNT(*) AS total
        FROM visitors
        WHERE DATE(checkin_time) = CURDATE()
        GROUP BY HOUR(checkin_time)
        ORDER BY hr
    """)
    rows = cur.fetchall()

    labels = [f"{r['hr']:02d}:00" for r in rows]
    values = [r['total'] for r in rows]

    return jsonify({"labels": labels, "values": values})
from openpyxl import Workbook
from flask import send_file
import io

@app.route("/export-excel")
def export_excel():
    if session.get("role") not in ["admin", "super_admin"]:
        return redirect("/")

    start = request.args.get("start")
    end = request.args.get("end")
    dept = request.args.get("department")

    query = "SELECT * FROM visitors WHERE 1=1"
    params = []

    if start and end:
        query += " AND DATE(checkin_time) BETWEEN %s AND %s"
        params.extend([start, end])

    if dept and dept != "All":
        query += " AND department=%s"
        params.append(dept)

    db = get_db()
    cur = db.cursor()
    cur.execute(query, params)
    rows = cur.fetchall()

    wb = Workbook()
    ws = wb.active
    ws.title = "Visitors"

    headers = [
        "ID","Full Name","Phone","Email","Gender","Address",
        "Purpose","Department","Person To Meet","Check-in Time"
    ]
    ws.append(headers)

    for r in rows:
        ws.append([
            r["id"], r["full_name"], r["phone"], r["email"], r["gender"],
            r["address"], r["purpose"], r["department"],
            r["person_to_meet"], r["checkin_time"]
        ])

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)

    return send_file(
        output,
        download_name="visitor_report.xlsx",
        as_attachment=True
    )


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
